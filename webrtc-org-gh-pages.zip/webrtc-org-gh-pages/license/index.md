---
layout: default
title: License
permalink: /license/
crumb: License
---


The WebRTC source code License and Additional IP Rights Grant can be found
here:

  * [WebRTC Software License](software/)

  * [WebRTC Additional IP Rights Grant](additional-ip-grant/)

  * [iLBC Freeware]({{ site.baseurl }}/license/ilbc-freeware/)

    * ([iLBC Extra Documentation]({{ site.baseurl }}/license/ilbc-freeware/ilbc-extra-documentation/))