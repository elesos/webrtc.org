---
layout: default
title: Conferences
author: Serge Lachapelle
date: 2011-09-01 03:05:00
---


A quick note about upcoming events we will be participating at. My colleague
Jan will be at [OVC 2011][1] in NYC on Sept 10th to 12th. He will be
presenting along with Tim from Mozilla.

Later on, I will do a presentation at [IIT's Real Time Communications][2]
October 4-6th in Chicago.

Feel free to reach out if you happen to be there and have any WebRTC questions
or comments / suggestions. We will surely attend more events this year, so
stay tuned!

[1]: http://openvideoconference.org/
[2]: http://www.cvent.com/events/7th-annual-real-time-communications-conference-and-expo/event-summary-ffc3acffa5af4bddae7a33f788e37f56.aspx
