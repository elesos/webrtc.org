---
layout: default
title: WebRTC Team @ IETF 81 Meeting in Québec, Canada
author: Serge Lachapelle
date: 2011-07-06 04:55:00
---


Members of the team (@juberti, @alvestrand, @jtlinden) will be attending
[IETF 81 in Québec, Canada, July 24th to July 30th][1]. We will also be
attending the [W3C F2F][2] on Saturday, July 23rd.

[1]: https://www.ietf.org/proceedings/81/index.html
[2]: http://www.w3.org/2011/04/webrtc/Overview.html#meeting
