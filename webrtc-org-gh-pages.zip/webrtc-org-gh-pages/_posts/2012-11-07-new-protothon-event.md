---
layout: default
title: New Protothon Event
author: Serge Lachapelle
date: 2012-11-07 10:32:00
---

In case you missed it, Google will be hosting a new protothon event at the end
of the month. The last day to apply is this Friday (the 9th of November).

We're hosting it at an amazing venue, [Campus London] and have a great day
planned for those of you that would like to get creative with the Web Audio
and WebRTC APIs. Read more [here].

[Campus London]: https://www.campuslondon.com
[here]: http://www.protothon.com/
