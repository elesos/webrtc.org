---
layout: default
title: PeerConnection in Chrome 23 Beta
author: Serge Lachapelle
date: 2012-10-02 10:50:00
---

Chrome M23 Beta now serves PeerConnection API without a Flag.

Blog post by [+Justin Uberti] here:
<http://blog.chromium.org/2012/10/supporting-new-media-experiences-on-web.html>

[1]: https://plus.google.com/103619602351433955946
