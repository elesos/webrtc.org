---
layout: default
title: WebRTC Can Now Be Enabled in chrome://flags
author: Serge Lachapelle
date: 2012-01-25 05:28:00
---


Today, we posted a page that includes instructions for enabling WebRTC in
Chrome and testing it out on a few user submitted demoes. You can now enable
WebRTC using chrome://flags

More info [here]({{ site.baseurl }}/web-apis/chrome/).