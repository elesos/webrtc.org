---
layout: default
title: A New Home for WebRTC News
author: Serge Lachapelle
date: 2013-11-12 05:56:00
---

Thanks for following along here over the past two years as we've shared news
and updates related to WebRTC. Going forward, we'll start to share this
content on the more up-to-date [Chromium Blog][1], so we thought it was time
to officially say goodbye here.

See you [over there][1]!


[1]: http://blog.chromium.org/