---
layout: default
title: "Quick Note: WebRTC API Specification at W3C"
author: Serge Lachapelle
date: 2011-08-30 12:01:00
---


Just a quick note to say that we have updated the site to mention the W3C
draft spec. The W3C workgroup has been working further on the WHATWG proposal
we initially (almost) implemented. We are currently implementing the W3C spec,
being well aware that it is highly volatile and subject to heavy change.

<http://dev.w3.org/2011/webrtc/editor/webrtc.html>
