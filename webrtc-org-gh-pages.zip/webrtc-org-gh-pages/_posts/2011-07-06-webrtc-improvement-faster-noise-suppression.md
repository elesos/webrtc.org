---
layout: default
title: "WebRTC Improvement: Instant Noise Suppression"
author: Serge Lachapelle
date: 2011-07-06 06:27:00
---


While we are busy integrating the WebRTC platform in web browsers, we are also
heads down in improving the platform and components. We'll be sharing these
improvements with you as they become available.

Today, I'd like to share the first major improvement. We've made significant
optimizations to the WebRTC's noise suppressor, cutting out noise instantly.
Code is checked-in and, of course, freely available for use.
