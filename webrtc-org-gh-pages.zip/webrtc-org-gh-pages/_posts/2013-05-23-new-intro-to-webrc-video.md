---
layout: default
title: New Intro to WebRTC Video
author: Justin Uberti
date: 2013-05-23 16:26:00
---

Here's the video from the WebRTC session at Google I/O 2013, which gives a
good look at the current state of the WebRTC universe.

<div class="embed-responsive embed-responsive-16by9 yt-embed">
  <iframe width="560" height="315" src="https://www.youtube.com/embed/p2HzZkd2A40" frameborder="0" allowfullscreen></iframe>
</div>
