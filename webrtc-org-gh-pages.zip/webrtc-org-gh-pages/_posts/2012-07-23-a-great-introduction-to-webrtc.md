---
layout: default
title: A Great Introduction to WebRTC
author: Serge Lachapelle
date: 2012-07-23 05:36:00
---

Hi, Justin Uberti gave a great overview of WebRTC at Google I/O. Highly
recommended viewing for anyone wanting an introduction.

<div class="embed-responsive embed-responsive-16by9 yt-embed">
  <iframe width="560" height="315" src="https://www.youtube.com/embed/E8C8ouiXHHk" frameborder="0" allowfullscreen></iframe>
</div>