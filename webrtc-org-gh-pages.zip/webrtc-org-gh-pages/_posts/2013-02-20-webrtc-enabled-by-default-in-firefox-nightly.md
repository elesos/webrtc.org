---
layout: default
title: WebRTC Enabled By Default in Firefox Nightly
author: Maire Reavy
date: 2013-02-20 09:48:00
---


All of the WebRTC code is now enabled by default in Firefox Nightly.
Previously, you needed to go to about:config in Firefox and set the
`media.peerconnection.enabled` option to true to use the feature, but now it's
enabled by default.
