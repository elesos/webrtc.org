---
layout: default
title: Contribute Bug Fixes to WebRTC
author: Serge Lachapelle
date: 2011-09-12 03:00:00
---


Our code base is now  open to third party code contributions. Our first
milestone is to welcome contributions in the form of [bug fixes][1].

We'll tackle new features-style contributions in a little while, as we are
heads down in getting the first browsers with WebRTC support available.

Read more about how to contribute [here][2]!

[1]: http://code.google.com/p/webrtc/issues/list
[2]: {{ site.baseurl }}/contributing/
