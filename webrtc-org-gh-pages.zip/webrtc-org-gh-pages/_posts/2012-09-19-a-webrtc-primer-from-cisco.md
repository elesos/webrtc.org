---
layout: default
title: A WebRTC Primer from Cisco's Cullen Jennings
author: Serge Lachapelle
date: 2012-09-19 05:36:00
---

Cullen Jennings, co-chair of the IETF RTCWeb working group, posted this intro
to WebRTC on [Vimeo]. It's a good primer.

[Vimeo] :http://vimeo.com/47682405