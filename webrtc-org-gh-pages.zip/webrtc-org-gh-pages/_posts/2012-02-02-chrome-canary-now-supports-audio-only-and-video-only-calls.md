---
layout: default
title: Chrome Canary Now Supports Audio-only and Video-only Calls
author: Serge Lachapelle
date: 2012-02-02 06:23:00
---


Quick note: Chrome Canary now support calling with only audio or only video.
