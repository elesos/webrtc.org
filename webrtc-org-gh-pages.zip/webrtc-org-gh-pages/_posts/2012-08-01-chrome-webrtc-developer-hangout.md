---
layout: default
title: Chrome WebRTC Developer Hangout
author: Serge Lachapelle
date: 2012-08-01 08:38:00
---

Recorded stream:

<div class="embed-responsive embed-responsive-16by9 yt-embed">
  <iframe width="560" height="315" src="https://www.youtube.com/embed/7GYzx1dZUWM" frameborder="0" allowfullscreen></iframe>
</div>