---
layout: default
title: Troubleshooting
permalink: /troubleshooting/
---

### Self-test Page

Having problems using WebRTC enabled web sites with your browser? Go to
[test.webrtc.org](https://test.webrtc.org) and try out our self-test. It will produce a log
that is very useful to include when filing a bug.


### Searching already filed bugs

Sometimes there's a known workaround for a bug. Search the bug trackers listed
at the [Report bugs]({{ site.baseurl }}/bugs/) page.
